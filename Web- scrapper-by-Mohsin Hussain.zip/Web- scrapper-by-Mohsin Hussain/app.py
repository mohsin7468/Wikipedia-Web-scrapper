from flask import Flask, render_template, request
import requests
from bs4 import BeautifulSoup

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/process_form', methods=['POST'])
def process_form():
    url = request.form['url']

    # Send a GET request to the Wikipedia page
    response = requests.get(url)

    # Parse the HTML content using BeautifulSoup
    soup = BeautifulSoup(response.content, "html.parser")

    # Find and extract specific elements from the page
    title = soup.find(id="firstHeading").text
    paragraphs = soup.select("#mw-content-text p")
    paragraphText = ""

    for paragraph in paragraphs:
        paragraphText += paragraph.text + "\n"

    data = {
        "title": title,
        "paragraphs": paragraphText
    }
    return render_template('response.html', data=data)

if __name__ == '__main__':
    app.run()
